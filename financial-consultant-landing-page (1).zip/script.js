// Mobile Navigation Toggle
const mobileToggle = document.getElementById("mobile-toggle")
const navMenu = document.getElementById("nav-menu")

mobileToggle.addEventListener("click", () => {
  navMenu.classList.toggle("active")
  mobileToggle.classList.toggle("active")
})

// Close mobile menu when clicking on a link
const navLinks = document.querySelectorAll(".nav-link")
navLinks.forEach((link) => {
  link.addEventListener("click", () => {
    navMenu.classList.remove("active")
    mobileToggle.classList.remove("active")
  })
})

// Smooth Scrolling
document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
  anchor.addEventListener("click", function (e) {
    e.preventDefault()
    const target = document.querySelector(this.getAttribute("href"))
    if (target) {
      const offsetTop = target.offsetTop - 70
      window.scrollTo({
        top: offsetTop,
        behavior: "smooth",
      })
    }
  })
})

// Navbar Scroll Effect
const navbar = document.getElementById("navbar")
let lastScroll = 0

window.addEventListener("scroll", () => {
  const currentScroll = window.pageYOffset

  if (currentScroll > 100) {
    navbar.classList.add("scrolled")
  } else {
    navbar.classList.remove("scrolled")
  }

  lastScroll = currentScroll
})

// Animated Counter for Stats
const animateCounter = (element, target, duration = 2000) => {
  let current = 0
  const increment = target / (duration / 16)
  const suffix = element.parentElement.querySelector(".stat-label").textContent.includes("Kepuasan") ? "%" : "+"

  const timer = setInterval(() => {
    current += increment
    if (current >= target) {
      element.textContent = target + suffix
      clearInterval(timer)
    } else {
      element.textContent = Math.floor(current) + suffix
    }
  }, 16)
}

// Intersection Observer for Counter Animation
const counterObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        const target = Number.parseInt(entry.target.getAttribute("data-target"))
        animateCounter(entry.target, target)
        counterObserver.unobserve(entry.target)
      }
    })
  },
  { threshold: 0.5 },
)

document.querySelectorAll(".stat-number").forEach((counter) => {
  counterObserver.observe(counter)
})

// Scroll to Top Button
const scrollTopBtn = document.getElementById("scroll-top")

window.addEventListener("scroll", () => {
  if (window.pageYOffset > 500) {
    scrollTopBtn.classList.add("show")
  } else {
    scrollTopBtn.classList.remove("show")
  }
})

scrollTopBtn.addEventListener("click", () => {
  window.scrollTo({
    top: 0,
    behavior: "smooth",
  })
})

// Contact Form Submission
const contactForm = document.getElementById("contact-form")
const formSuccess = document.getElementById("form-success")

contactForm.addEventListener("submit", (e) => {
  e.preventDefault()

  // Get form data
  const formData = {
    name: document.getElementById("name").value,
    email: document.getElementById("email").value,
    phone: document.getElementById("phone").value,
    service: document.getElementById("service").value,
    message: document.getElementById("message").value,
  }

  // Simulate form submission
  console.log("Form submitted:", formData)

  // Show success message
  contactForm.style.display = "none"
  formSuccess.classList.add("show")

  // Reset form after 5 seconds
  setTimeout(() => {
    contactForm.style.display = "flex"
    formSuccess.classList.remove("show")
    contactForm.reset()
  }, 5000)
})

// Newsletter Form
const newsletterForm = document.querySelector(".newsletter-form")

newsletterForm.addEventListener("submit", (e) => {
  e.preventDefault()
  const email = newsletterForm.querySelector("input").value
  console.log("Newsletter subscription:", email)
  alert("Terima kasih telah berlangganan newsletter kami!")
  newsletterForm.reset()
})

// Scroll Animation for Elements
const observerOptions = {
  threshold: 0.1,
  rootMargin: "0px 0px -100px 0px",
}

const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = "1"
      entry.target.style.transform = "translateY(0)"
    }
  })
}, observerOptions)

// Observe service cards and benefit cards
document.querySelectorAll(".service-card, .benefit-card, .additional-item, .value-item").forEach((el) => {
  el.style.opacity = "0"
  el.style.transform = "translateY(30px)"
  el.style.transition = "all 0.6s ease"
  observer.observe(el)
})

// Active Navigation Link on Scroll
const sections = document.querySelectorAll("section[id]")

const highlightNav = () => {
  const scrollY = window.pageYOffset

  sections.forEach((section) => {
    const sectionHeight = section.offsetHeight
    const sectionTop = section.offsetTop - 100
    const sectionId = section.getAttribute("id")

    if (scrollY > sectionTop && scrollY <= sectionTop + sectionHeight) {
      document.querySelector(`.nav-link[href*="${sectionId}"]`)?.classList.add("active")
    } else {
      document.querySelector(`.nav-link[href*="${sectionId}"]`)?.classList.remove("active")
    }
  })
}

window.addEventListener("scroll", highlightNav)

// Add active class style
const style = document.createElement("style")
style.textContent = `
    .nav-link.active {
        color: var(--primary-color);
    }
    .nav-link.active::after {
        width: 100%;
    }
`
document.head.appendChild(style)

// Lazy Loading Images (additional enhancement)
const images = document.querySelectorAll("img[data-src]")
const imageObserver = new IntersectionObserver((entries, observer) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      const img = entry.target
      img.src = img.dataset.src
      img.removeAttribute("data-src")
      imageObserver.unobserve(img)
    }
  })
})

images.forEach((img) => imageObserver.observe(img))

// Form Validation Enhancement
const inputs = document.querySelectorAll("input, select, textarea")

inputs.forEach((input) => {
  input.addEventListener("blur", () => {
    if (input.value.trim() === "" && input.hasAttribute("required")) {
      input.style.borderColor = "#ef4444"
    } else {
      input.style.borderColor = "var(--border-color)"
    }
  })

  input.addEventListener("focus", () => {
    input.style.borderColor = "var(--primary-color)"
  })
})

// Console message
console.log("%c🚀 ProFinance Consulting Website", "color: #2563eb; font-size: 20px; font-weight: bold;")
console.log("%cWebsite loaded successfully!", "color: #10b981; font-size: 14px;")
